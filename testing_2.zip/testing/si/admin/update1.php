<?php
print"Status Changed !!";
if(isset($_POST['update']))
{
    $cid=$_POST['cid'];
    $status=$_POST['status'];


    include("connect.php");
    $sql_connect=mysql_connect($host,$user,$pass) or die("cannot connect to database.please try after sometime");
    mysql_select_db($db,$sql_connect) or die("cannot find database");

    $select_user_query="SELECT * FROM `courier_table` WHERE `cid`='$cid'";
    $select_user=mysql_query($select_user_query);
    //	$row=mysql_fetch_row($select_user);
    //	$correctpass=$u['password'];
    $change=mysql_query("UPDATE `courier`.`courier_table` SET `status`='$status' WHERE `courier_table`.`cid`='$cid'");
    //session_start();
    //$_SESSION['change']=1;
    include("update.php");
    echo "Status Changed !!";



}

?>
<?php include('header.php') ?>
<nav class="navbar navbar-default">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="#">Courier Management System</a>
        </div>
        <div class="collapse navbar-collapse" id="myNavbar">
            <ul class="nav navbar-nav">
                <li class="active"><a href="admin.php">Home</a></li>
                <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
            </ul>

        </div>
    </div>
</nav>
<div class="container">
    <div class="row">
        <div class="col-lg-6 col-md-6 col-sm-6 col-sm-offset-3">
            <div class="panel panel-primary">
                <div class="panel panel-heading">
                    Update Courier Status
                </div>
                <div class="panel panel-body">
                    <form action="updatestatus.php" method="post">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

                        <label >Courier ID:</label>
                       <input type='text' name='cid' class="form-control" />
                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

                        <label >New Status:</label>
                       <select name="status" class="form-control">
                                <option value = "Paid">Paid</option>
                                <option value = "Pending">Pending</option>
                                <option value = "Delivered">Delivered</option>
                            </select>
                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <input type='submit' name='update' class="btn btn-primary btn-block" value='Update' />
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
