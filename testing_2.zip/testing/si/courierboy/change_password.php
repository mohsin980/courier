<?php

if(isset($_POST['submit']))
{
    $u=$_POST['username'];
    $op=$_POST['opassword'];
    $np=$_POST['npassword'];

    include("connect.php");
    $sql_connect=mysql_connect($host,$user,$pass) or die("cannot connect to database.please try after sometime");
    mysql_select_db($db,$sql_connect) or die("cannot find database");

    $select_user_query="SELECT * FROM `courier_boy` WHERE `username`='$u' AND `password`='$op'";
    $select_user=mysql_query($select_user_query);
    //	$row=mysql_fetch_row($select_user);
    //	$correctpass=$u['password'];
    $change=mysql_query("UPDATE `courier`.`courier_boy` SET `password`='$np' WHERE `courier_boy`.`username`='$u'");
    session_start();
    $_SESSION['change']=1;
    echo "Password Changed Successfully";
    header("Location: change_password.php");
}
?>
<?php include('header.php') ?>
<nav class="navbar navbar-default">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="#">Courier Management System</a>
        </div>
        <div class="collapse navbar-collapse" id="myNavbar">
            <ul class="nav navbar-nav">
                <li class="active"><a href="courier_boy.php">Home</a></li>
                <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
            </ul>

        </div>
    </div>
</nav>

<body>

    <div class="container">
        <div class="col-md-6 col-sm-offset-3">
        <div class="panel panel-default">
                <div class="panel panel-heading">
                    <h4>Change Password</h4>
                </div>
                    <form action='' method='post'>
                        <div class="panel panel-body">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <label for="name">Username:</label>
                                   <input type='text' name='username' class="form-control">
                                </div>
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <label for="password">Old Password:</label>
                               <input type='password' name='opassword' class="form-control">
                                </div>
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <label for="password">New Password:</label>
                                  <input type='password' name='npassword' class="form-control">
                                </div>
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <br>  <input type='submit' name='submit' value='Change' class="btn btn-primary btn-block" >
                        </div>
                                </div>
                    </form>
            </div>
    </div>
    </div>

</body>