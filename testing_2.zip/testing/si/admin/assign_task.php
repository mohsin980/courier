<?php include('header.php') ?>
    <body>
    <?php
    $con=mysql_connect("localhost","root","");
    if(!$con)
    {
        die('could not connect'.mysql_error());
    }
    mysql_select_db("courier",$con);
    $sql="select * from courier_boy";
    $sql1="select * from courier_table";
    $result=mysql_query($sql,$con);
    $result1=mysql_query($sql1,$con);
    ?>

    </body>

<?php include('header.php') ?>
    <nav class="navbar navbar-default">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">Courier Management System</a>
            </div>
            <div class="collapse navbar-collapse" id="myNavbar">
                <ul class="nav navbar-nav">
                    <li class="active"><a href="admin.php">Home</a></li>
                    <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
                </ul>

            </div>
        </div>
    </nav>
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6 col-sm-offset-3">
                <div class="panel panel-primary">
                    <div class="panel panel-heading">
                        Assign Task
                    </div>
                    <div class="panel panel-body">
                        <form action="process.php" method="post">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

                                <label >Courier Boy:</label>
                                <select name="username" class="form-control">
                                    <?php  while( $row=mysql_fetch_row($result))
                                    { ?>

                                        <option value = "<?= $row[1] ?>"><?= $row[1] ?></option>
                                    <?php } ?>
                                </select>   </div>
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

                                <label >Order #:</label>
                                <select name="ctid" class="form-control">
                                    <?php  while( $row=mysql_fetch_row($result1))
                                    { ?>
                                        <option value = "<?= $row[0] ?>"><?= $row[0] ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <br> <input type='submit' name='update' class="btn btn-primary btn-block" value='Update' />
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php ?>