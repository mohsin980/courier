<?php include "header.php"; ?>
<?php
include("connect.php");
if(isset($_POST["update"]) && $_POST["update"]!="") {
    $usersCount = count($_POST["cid"]);
    for($i=0;$i<$usersCount;$i++) {
        mysql_query("UPDATE courier_table set rname='" . $_POST["rname"][$i] . "', cno='" . $_POST["cno"][$i] . "', email='" .
            $_POST["email"][$i] . "', amount='" . $_POST["amount"][$i] . "',order_no='".$_POST['order_no'][$i]."',address='".$_POST['address'][$i]."',
            username='".$_POST['username'][$i]."',status='".$_POST['status'][$i]."'
             WHERE cid='" . $_POST["cid"][$i] . "'")  or die(mysql_error());
    }

} ?>

<?php  ?>