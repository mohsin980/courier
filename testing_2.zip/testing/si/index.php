<?php include "header.php"; ?>
<body>
		<div id="home" class="container">
            <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6 col-sm-offset-3 col-xs-12 col-xss-12">
                <p>&nbsp;</p>
                <div class="clear h40"></div>
                <div class="panel panel-primary">
                            <div class="panel-heading" align="center">
                                <h4>User Login</h4>
                            </div>
                        <div class="panel panel-body">
                            <form action='auth.php' method='post'>
                            <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
                                <label for="Name">Username:</label>
                                <input type='text' name='username' class="form-control">
                            </div>
                                <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
                                    <label for="password">Password:</label>
                                <input type='password' name='password' class="form-control">
                            </div>

                                <?php // To display Error messages
                             //   if(isset($_GET['err'])){
                               //     if ($_GET['err']==1){
                                 //       echo "Invalid Credentials.Try username:codefreax, password:password";}
                                   // else if($_GET['err']==5){
                                     //   echo "Successfully Logged out..";}
                                   // else if ($_GET['err']==2){
                                     //   echo "Your trying to access unauthorized page.Please login first";
                                   // }
                              //  }
                                ?>
                                <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12"><br>
                                    <input type='submit' name='submit' value='Login' class="btn btn-primary "></div></form>
                            <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">

                        </div>
                    	</div>


            </div>


        </div> <!-- END of home -->
        </div>




</body> 
</html>