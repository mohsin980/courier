<?php include "header.php"; ?>
<div class="row">
  <div class="col-lg-9 col-xs-12">
    <!-- PAGE CONTENT BEGINS -->
<div class="page-header">
    							<h1>
    								Dashboard
    								<small>
    									<i class="ace-icon fa fa-angle-double-right"></i>
    									overview &amp; stats
    								</small>
    							</h1>
    						</div><!-- /.page-header -->
    <div class="row">
      <div class="space-6"></div>

      <div class="col-sm-12 infobox-container">
        <div class="infobox infobox-green">
          <div class="infobox-icon">
            <i class="ace-icon fa fa-shopping-cart"></i>
          </div>
          <div class="infobox-data">
            <span class="infobox-data-number">  <?php
              include "connect.php";
              $sql1="select count(*) as total from courier_table ";
              $res = mysql_query($sql1,$con);
              while ($row = mysql_fetch_assoc($res))
                  echo  "$row[total]";
              ?></span>
            <div class="infobox-content">Total orders</div>
          </div>
        </div>
        <div class="infobox infobox-green">
          <div class="infobox-icon">
            <i class="ace-icon fa fa-shopping-cart"></i>
          </div>
          <div class="infobox-data">
            <span class="infobox-data-number">  <?php
              include "connect.php";
              $sql1="select count(*) as total from courier_table WHERE status='delivered' ";
              $res = mysql_query($sql1,$con);
              while ($row = mysql_fetch_assoc($res))
                  echo  "$row[total]";
              ?></span>
            <div class="infobox-content">Delivered orders</div>
          </div>
        </div>
        <div class="infobox infobox-green">
          <div class="infobox-icon">
            <i class="ace-icon fa fa-shopping-cart"></i>
          </div>
          <div class="infobox-data">
            <span class="infobox-data-number">  <?php
              include "connect.php";
              $sql1="select count(*) as total from courier_table WHERE status='returned' ";
              $res = mysql_query($sql1,$con);
              while ($row = mysql_fetch_assoc($res))
                  echo  "$row[total]";
              ?></span>
            <div class="infobox-content">Returned orders</div>
          </div>
        </div>
        <div class="infobox infobox-green">
          <div class="infobox-icon">
            <i class="ace-icon fa fa-shopping-cart"></i>
          </div>
          <div class="infobox-data">
            <span class="infobox-data-number">  <?php
              include "connect.php";
              $sql1="select count(*) as total from courier_table WHERE status='in transit' ";
              $res = mysql_query($sql1,$con);
              while ($row = mysql_fetch_assoc($res))
                  echo  "$row[total]";
              ?></span>
            <div class="infobox-content">Dispatched orders</div>
          </div>
        </div>
        <div class="infobox infobox-green">
          <div class="infobox-icon">
            <i class="ace-icon fa fa-users"></i>
          </div>
          <div class="infobox-data">
            <span class="infobox-data-number">  <?php
              include "connect.php";
              $sql1="select count(*) as total from users  ";
              $res = mysql_query($sql1,$con);
              while ($row = mysql_fetch_assoc($res))
                  echo  "$row[total]";
              ?></span>
            <div class="infobox-content">No. of Users</div>
          </div>
        </div>
        <div class="infobox infobox-green">
          <div class="infobox-icon">
            <i class="ace-icon fa fa-users"></i>
          </div>
          <div class="infobox-data">
            <span class="infobox-data-number">  <?php
              include "connect.php";
              $sql1="select count(*) as total from users WHERE user_type='admin' ";
              $res = mysql_query($sql1,$con);
              while ($row = mysql_fetch_assoc($res))
                  echo  "$row[total]";
              ?></span>
            <div class="infobox-content">No. of Admin</div>
          </div>
        </div>
        <div class="infobox infobox-green">
          <div class="infobox-icon">
            <i class="ace-icon fa fa-users"></i>
          </div>
          <div class="infobox-data">
            <span class="infobox-data-number">  <?php
              include "connect.php";
              $sql1="select count(*) as total from users WHERE user_type='employee' ";
              $res = mysql_query($sql1,$con);
              while ($row = mysql_fetch_assoc($res))
                  echo  "$row[total]";
              ?></span>
            <div class="infobox-content">No. of Employee</div>
          </div>
        </div>
        <div class="infobox infobox-green">
          <div class="infobox-icon">
            <i class="ace-icon fa fa-users"></i>
          </div>
          <div class="infobox-data">
            <span class="infobox-data-number">  <?php
              include "connect.php";
              $sql1="select count(*) as total from users WHERE user_type='courier_boy' ";
              $res = mysql_query($sql1,$con);
              while ($row = mysql_fetch_assoc($res))
                  echo  "$row[total]";
              ?></span>
            <div class="infobox-content">No. of Courier Boy</div>
          </div>
        </div>
        <div class="space-6"></div>

        <div class="infobox infobox-blue infobox-small infobox-dark">
          <div class="infobox-chart">
            <span class="sparkline" data-values="3,4,2,3,4,4,2,2"></span>
          </div>

          <div class="infobox-data">
            <div class="infobox-content">Earnings</div>

            <div class="infobox-content"> <?php
              include "connect.php";
              $sql1="select * from courier_table WHERE status='delivered' ";
              $res = mysql_query($sql1,$con);
  $sum = 0;
              while ($row = mysql_fetch_assoc($res))
                  $sum += $row['amount'];
echo $sum;

              ?></div>
          </div>
        </div>
        <div class="infobox infobox-blue infobox-small infobox-dark">
          <div class="infobox-chart">
            <span class="sparkline" data-values="3,4,2,3,4,4,2,2"></span>
          </div>

          <div class="infobox-data">
            <div class="infobox-content">Returned </div>

            <div class="infobox-content"> <?php
              include "connect.php";
              $sql1="select * from courier_table WHERE status='returned' ";
              $res = mysql_query($sql1,$con);
  $sum = 0;
              while ($row = mysql_fetch_assoc($res))
                  $sum += $row['amount'];
echo $sum;

              ?></div>
          </div>
        </div>
        <div class="infobox infobox-blue infobox-small infobox-dark">
          <div class="infobox-chart">
            <span class="sparkline" data-values="3,4,2,3,4,4,2,2"></span>
          </div>

          <div class="infobox-data">
            <div class="infobox-content" style="width:350px">Pending Amt</div>

            <div class="infobox-content"> <?php
              include "connect.php";
              $sql1="select * from courier_table WHERE status='in transit' ";
              $res = mysql_query($sql1,$con);
      $sum = 0;
              while ($row = mysql_fetch_assoc($res))
                  $sum += $row['amount'];
      echo $sum;

              ?></div>
          </div>
        </div>
      <div class="vspace-12-sm"></div>


    </div><!-- /.row -->

    <div class="hr hr32 hr-dotted"></div>
</div>
</div>
</body>
</html>
