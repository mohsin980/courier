<?php include "header.php"; ?>
<?php
include("connect.php");
if(isset($_POST["update"]) && $_POST["update"]!="") {
    $usersCount = count($_POST["cid"]);
    for($i=0;$i<$usersCount;$i++) {
        $sql4 = mysql_query("UPDATE courier_table set order_no='" . $_POST['order_no'][$i] . "',status='" . $_POST['status'][$i] . "'
             WHERE cid='" . $_POST["cid"][$i] . "'") or die(mysql_error());


    }
}
?>
