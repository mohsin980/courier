<?php
$host='localhost';
$user='nextcfgi';
$pass='Websites2017';
$db='nextcfgi_drup125';
$con=mysql_connect($host,$user,$pass);
if(!$con)
{
    die('could not connect'.mysql_error());
}

mysql_select_db($db,$con);
?>