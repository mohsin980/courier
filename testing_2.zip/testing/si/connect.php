<?php
$host='localhost';
$user='nextcfgi';
$pass='Websites2017';
$db='nextcfgi_drup125';
?>