<?php include "header.php"; ?>
<?php
include("connect.php");
if(isset($_POST["update"]) && $_POST["update"]!="") {
    $usersCount = count($_POST["cid"]);
    for($i=0;$i<$usersCount;$i++) {
        mysql_query("UPDATE courier_table set order_no='".$_POST['order_no'][$i]."',status='".$_POST['status'][$i]."'
             WHERE cid='" . $_POST["cid"][$i] . "'")  or die(mysql_error());

    }

} ?>
    <div class="user-dashboard">
        <div >
            <div class="col-lg-6 col-md-6 col-sm-6 col-sm-offset-3">
                <div class="panel panel-primary">
                    <div class="panel panel-heading">
                        Update Courier Status
                    </div>
                    <div class="panel panel-body">
                        <?php   ?>
                        <form action="updatestatus1.php" method="post">

                            <?php $rowCount = count($_POST["name"]);
                            for($i=0;$i<$rowCount;$i++) {
                                $sql1 = mysql_query("SELECT * FROM courier_table WHERE cid='" . $_POST["name"][$i] . "'") or die(mysql_error());
                                $row[$i]= mysql_fetch_array($sql1);
                                ?>
                                <div class="panel panel-body">
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        <label for="name">Order # :</label>
                                        <input type="hidden" name="cid[]" class="txtField" value="<?php echo $row[$i][0]; ?>">
                                        <input name="order_no[]" type="number" value="<?= $row[$i][5] ?>"   class="form-control" readonly>

                                    </div>
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        <label for="address"></label>
                                        <input name="date[]"  type="hidden"  id="saddress" class="form-control" required>
                                    </div>
                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                        <label>Status</label>
                                        <select name="status[]" class="form-control" required>
                                            <option value="In Transit" <?php if($row[$i][9]=="")  echo 'selected="selected"';  ?>></option>
                                            <option value="In Transit" <?php if($row[$i][9]=="In Transit")  echo 'selected="selected"';  ?>>In Transist</option>
                                            <option value="Delivered" <?php if($row[$i][9]=="Delivered") echo 'selected="selected"';    ?>>Delivered</option>
                                            <option value="Returned" <?php if($row[$i][9]=="Returned")  echo 'selected="selected"'; ?>>Returned</option>
                                        </select>
                                    </div>
                                </div>
                            <?php  } ?>
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <input type='submit' name='update' class="btn btn-primary btn-block" value='Update' />
                            </div>

                        </form>
                        <?php // } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php  ?>