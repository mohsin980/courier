<?php
include("connect.php");
if(isset($_POST["update"]) && $_POST["update"]!="") {
    $usersCount = count($_POST["name"]);
  $i=0;
    while ($i<$usersCount){
        $sql4 = mysql_query("UPDATE courier_table set status='" . $_POST['status'][$i] . "'
             WHERE cid='" . $_POST["name"][$i] . "'") or die(mysql_error());

        $result = mysql_query($sql4, $con);
        if($result){
            echo "error";

        }else
        {
            header('Location: ' . $_SERVER['HTTP_REFERER']);
        }
    }
    $i++;

}

?>
