<?php include ('header.php')?>

<nav class="navbar navbar-default">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="#">Courier Management System</a>
        </div>
        <div class="collapse navbar-collapse" id="myNavbar">
            <ul class="nav navbar-nav">
                <li class="active"><a href="../logging.php">Home</a></li>
                <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
            </ul>

        </div>
    </div>
</nav>

<body>
<div class="section">
    <div class="container">
        <div class="panel panel-default">
            <div class="panel panel-heading">Assigned Tasks</div>
            <div class="panel panel-body">
<?php

$con=mysql_connect("localhost","root","");
if(!$con)
{
    die('could not connect'.mysql_error());
}
mysql_select_db("courier",$con);


$sql1="SELECT courier_table.cid,courier_table.sname,courier_table.rname,courier_table.date,courier_table.status,courier_boy_task.ctid
FROM courier_table
 JOIN courier_boy_task
ON courier_table.cid = courier_boy_task.ctid";
$result1=mysql_query($sql1,$con);
if(!$result1)
{
    echo "Error!" . "</br>";
    include 'report.php';
}
else {
    echo "<table>";
    echo"<thead><th>Cid</th><th>Sender name </th><th>Reciever name </th><th>Date </th><th>Status</th></thead>";
    while( $row=mysql_fetch_row($result1))
    {

        echo "<tr><td>$row[0]</td><td>$row[1]</td><td>$row[2]</td><td>$row[3]</td><td>$row[4]</td></tr>";


    }
    echo "</table>";echo "</br>";}





?>
            </div>
        </div>
    </div>
</div>
</body>
</html>
