<?php
require_once('includes/load.php');
if (!$session->isUserLoggedIn(true)) { redirect('index.php', false);} ?>
<?php  function current_user(){
    static $current_user;
    global $db;
    if(!$current_user){
        if(isset($_SESSION['user_id'])):
            $user_id = intval($_SESSION['user_id']);
 $username = $_SESSION['username'];
            $current_user = find_by_id('users',$user_id);
        endif;
    }
    return $current_user;
}
$user = current_user(); ?>
<?php  if ($session->isUserLoggedIn(true)): ?>

    <?php if($user['user_type'] === 'admin'): ?>
        <!-- admin menu -->
        <?php include('admin/admin1.php');?>

    <?php elseif($user['user_type'] === 'employee'): ?>
        <!-- Special user -->
        <?php include_once('employee/employee1.php');?>

    <?php elseif($user['user_type'] === 'courier_boy'): ?>
        <!-- User menu -->
<?php $user['username']= $_SESSION['username'] ?>
        <?php include_once('courierboy/courier_boy1.php');?>

    <?php endif;?>
<?php endif;?>
