<?php


$cid = $_GET['cid'];
include "connect.php";
$sql = "DELETE FROM courier_table WHERE `courier_table`.`cid`='$cid'";
$result = mysql_query($sql, $con);
if (!$result) {
    echo "Incorrect details !" . "</br>";
    include 'admin.php';
} else {

    include("reporting.php");
}

?>
