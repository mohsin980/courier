<?php


    $id = $_GET['id'];
include "connect.php";
    $sql = "DELETE FROM users WHERE `users`.`id`='$id'";

    $result = mysql_query($sql, $con);

    if (!$result) {
        echo "Incorrect details !" . "</br>";
        include 'admin.php';
    } else {

        include("viewemp.php");
    }

?>
