<?php include('header.php')?>
<body>
<div  class="user-dashboard">
    <div class="container">
<div class="row">
    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 col-xss-12">
        </div>
    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 col-xss-12">
        <div class="panel panel-primary">
            <div class="panel-heading">Total Orders</div>
            <div class="panel panel-body">
                <?php
                include "connect.php";
                $sql1="select count(*) as total from courier_table ";
                $res = mysql_query($sql1,$con);
                while ($row = mysql_fetch_assoc($res))
                echo  "$row[total]";
                ?>
            </div>
        </div></div>
    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 col-xss-12">
        <div class="panel panel-primary">
            <div class="panel-heading">Users</div>
            <div class="panel panel-body">
                <?php
                include "connect.php";
                $sql1="select count(*) as total1 from users ";
                $res = mysql_query($sql1,$con);
                while ($row = mysql_fetch_assoc($res))

                    echo  "$row[total1]";
                ?>
            </div>
        </div></div>
    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 col-xss-12">
        <div class="panel panel-primary">
            <div class="panel-heading">Total Amount</div>
            <div class="panel panel-body">
                <?php
                $sql4 = "select * from courier_table";
                $result1 = mysql_query($sql1, $con);
                // $result2=mysql_query($sql2,$con);
                // $result3=mysql_query($sql3,$con);
                $result4 = mysql_query($sql4, $con);
                // include("report1.php");
                if (!$result4) {
                    echo "Error!" . "</br>";
                   // include 'report.php';
                } else {
                    $sum = 0;
                    while ($row = mysql_fetch_assoc($result4)) {
                        $sum += $row['amount'];
                    }

                    echo $sum;
}
?>
            </div>
        </div></div>
    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 col-xss-12">
    </div>
    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 col-xss-12">
        <div class="panel panel-success">
            <div class="panel-heading">Delivered Orders</div>
            <div class="panel panel-body">
                <?php
                include "connect.php";
                $sql1="select count(*) as total from courier_table WHERE status='delivered'";
                $res = mysql_query($sql1,$con);
                while ($row = mysql_fetch_assoc($res))
                    echo  "$row[total]";
                ?>
            </div>
        </div></div>
    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 col-xss-12">
        <div class="panel panel-primary">
            <div class="panel-heading">Dispatched Orders</div>
            <div class="panel panel-body">
                <?php
                include "connect.php";
                $sql1="select count(*) as total1 from courier_table WHERE status='In Transit' ";
                $res = mysql_query($sql1,$con);
                while ($row = mysql_fetch_assoc($res))

                    echo  "$row[total1]";
                ?>
            </div>
        </div></div>
    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 col-xss-12">
        <div class="panel panel-danger">
            <div class="panel-heading">Returned Orders</div>
            <div class="panel panel-body">
                <?php
                include "connect.php";
                $sql1="select count(*) as total1 from courier_table WHERE status='Returned' ";
                $res = mysql_query($sql1,$con);
                while ($row = mysql_fetch_assoc($res))

                    echo  "$row[total1]";
                ?>
            </div>
        </div></div>
</div>
    </div>
            </div>
</body> <!-- END of home -->



