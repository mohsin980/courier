<?php

$con=mysql_connect("localhost","root","");
if(!$con)
{
    die('could not connect'.mysql_error());
}

mysql_select_db("courier",$con);

$sql="INSERT INTO courier_boy_task(username, ctid) VALUES ('$_POST[username]','$_POST[ctid]')";
$result=mysql_query($sql,$con);

if(!$result)
{
    echo "Incorrect details !" . "</br>";
    include 'assign_task.php';
}
else {echo  " added Successfully!";}
mysql_close($con);
?>
