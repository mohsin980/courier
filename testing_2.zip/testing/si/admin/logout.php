<?php
  require_once('includes/load.php');
  if(!$session->logout()) {redirect("http://cheapumrahuk.co.uk/testing/si");}
?>
