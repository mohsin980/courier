<body>
<?php
include  "connect.php";

$name   = $_POST['fname'];
$username   = $_POST['username'];
$password   = $_POST['password'];
$user_level = $_POST['user_type'];
$password = sha1($password);
$sql="INSERT INTO users (username, password,name,user_type,status) VALUES ('$username','$password','$name','$user_level','1')";
$result=mysql_query($sql,$con);

if(!$result)
{
echo "Incorrect details !" . "</br>";
include 'add_user.php';
}
else {echo  "User added !";}
mysql_close($con);
include 'viewemp.php';
?>

</body>
</html>
