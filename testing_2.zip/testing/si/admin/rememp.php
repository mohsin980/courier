
<?php include ('header.php')?>
<nav class="navbar navbar-default">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="#">Courier Management System</a>
        </div>
        <div class="collapse navbar-collapse" id="myNavbar">
            <ul class="nav navbar-nav">
                <li class="active"><a href="admin.php">Home</a></li>
                <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
            </ul>

        </div>
    </div>
</nav>
<div class="container" id="testimonial">


    <div class="row">
    <div class="col-lg-6 col-md-6 ol-sm-6 col-sm-offset-3">
        <div class="panel panel-primary">

            <script language="JavaScript" type="text/javascript">
                function validate()
                {
                    if (form.Consignment.value == "" )
                    {
                        alert("Consignment No is required.");
                        form.track.focus( );
                        return false;
                    }
                }
            </script>
            <div class="panel panel-heading"><h4> Remove Employee</h4>
            </div>
          <div class="panel panel-body">
                <label>Enter the Employee's username</label></td>
              <form action="remove_emp.php" method="post" name="form" id="form" >
                  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <input name="emp" class="form-control" id="emp"  type="text"  />
                  </div>
                  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"><br>
                            <input name="Submit" type="submit" class="btn btn-primary btn-block" value="Remove Employee">
                  </div>
                        </form>
          </div>


    </div>
    </div>
    </div>
</div>