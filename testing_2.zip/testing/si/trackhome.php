<?php include "header.php"?>

<body>
		<?php
        
			$con=mysql_connect("localhost","root","");
			if(!$con)
			{
			die('could not connect'.mysql_error());
			}
			
			mysql_select_db("courier",$con);
			
			
			$un=$_POST['username'];
			$cid=$_POST['cid'];
			
			$sql="select * from courier_table where sname='$un' and cid='$cid'";
			
			
			
			$result=mysql_query($sql,$con);
			if(!$result)
			{
			echo "Incorrect details !" . "</br>";
			include 'index.php';
			}
			else {
			echo "<div class='container'>";
			echo "<table>";
                while( $row=mysql_fetch_row($result))
                {
                    echo "<thead><th>Courier id</th><th>Sender's name</th><th>Status</th></thead>";
                    echo "<td>$row[0]</td><td>$row[3]</td><td>$row[9]</td>";
                }	echo "</table>";
			echo "</div>";
			}
        ?>

</body>
</html>
