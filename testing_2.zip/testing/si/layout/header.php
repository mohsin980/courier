<?php  function current_user(){
    static $current_user;
    global $db;
    if(!$current_user){
        if(isset($_SESSION['user_id'])):
            $user_id = intval($_SESSION['user_id']);
            $current_user = find_by_id('users',$user_id);
        endif;
    }
    return $current_user;
}
$user = current_user(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?php if (!empty($page_title))
            echo remove_junk($page_title);
        elseif(!empty($user))
            echo ucfirst($user['username']);
        else echo "Courier managemtn System";?>
    </title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css"/>
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker3.min.css" />
    <link rel="stylesheet" href="libs/css/main.css" />
</head>
<body>
<?php  if ($session->isUserLoggedIn(true)): ?>
    <?php if($user['user_type'] === 'admin'): ?>
            <!-- admin menu -->
            <?php include_once('admin/admin.php');?>

        <?php elseif($user['user_type'] === 'employee'): ?>
            <!-- Special user -->
            <?php include_once('employee/employee.php');?>

        <?php elseif($user['user_type'] === 'courier_boy'): ?>
            <!-- User menu -->
            <?php include_once('courierboy/courier_boy.php');?>

        <?php endif;?>
<?php endif;?>
