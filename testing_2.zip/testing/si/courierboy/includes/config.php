<?php

  define( 'DB_HOST', 'localhost' );          // Set database host
  define( 'DB_USER', 'nextcfgi' );             // Set database user
  define( 'DB_PASS', 'Websites2017' );             // Set database password
  define( 'DB_NAME', 'nextcfgi_drup125' );        // Set database name

?>
