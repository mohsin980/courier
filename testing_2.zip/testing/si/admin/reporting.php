<?php include "header.php"; ?>
<?php
include("connect.php");
if(isset($_POST["update"]) && $_POST["update"]!="") {
    $usersCount = count($_POST["name"]);
    for($i=0;$i<$usersCount;$i++) {
        $sql4 = mysql_query("UPDATE courier_table set status='" . $_POST['status'][$i] . "'
             WHERE cid='" . $_POST["name"][$i] . "'") or die(mysql_error());

        $result = mysql_query($sql4, $con);
        if(!$result){
            echo "error";

        }else
        {
            header('Location: ' . $_SERVER['HTTP_REFERER']);
        }
    }

}

?>
     <?php
            include "connect.php";

            // $sql1="select * from courier_table WHERE  date BETWEEN DATE_SUB(NOW(), INTERVAL 30 DAY) AND NOW();  /* where `status`='Paid'*/";
            $sql1 = "select * from  courier_table WHERE date > DATE_SUB(DATE(NOW()), INTERVAL 1 MONTH)
          ORDER BY date DESC";
             $sql2 ="select * from  courier_table WHERE date BETWEEN (CURRENT_DATE() - INTERVAL 1 MONTH) AND CURRENT_DATE()
ORDER BY date DESC";
             $sql3="select * from courier_table ORDER BY date DESC ";
     $sql4="select * from courier_table ";
     $result = mysql_query($sql1, $con);
$result1 = mysql_query($sql2, $con);
            $result2 = mysql_query($sql3, $con);
     $result3 = mysql_query($sql4, $con);


?>
<br><br>

	<div class = "col-lg-10">
			<a href="addc.php" class="btn btn-primary">Add Order <i class="fa fa-plus"></i></a>	
<div class="widget-box" id="widget-box-10">
												<div class="widget-header widget-header-small">
													<h5 class="widget-title smaller">Orders</h5>

													<div class="widget-toolbar no-border">
														<ul class="nav nav-tabs" id="myTab">
															<li class="active">
																<a data-toggle="tab" href="#home">Recent Month Orders</a>
															</li>

															<li>
																<a data-toggle="tab" href="#profile">Last month Order</a>
															</li>

															<li>
																<a data-toggle="tab" href="#info">All orders</a>
															</li>

                                                            <li>
                                                                <a data-toggle="tab" href="#date">Search </a>
                                                            </li>
														</ul>
													</div>
												</div>

												<div class="widget-body">
													<div class="widget-main padding-6">
														<div class="tab-content">
															<div id="home" class="tab-pane in active">
														
						 <form name="actionForm" action="updatestatus1.php" method="post" ><table ><tr>
					 	<td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td><select name="status[]" class="form-control" required><option value="">Bulk actions</option><option value="Delivered">Delivered</option><option value="In transit">Dispatch</option>
<option value="Returned">Returned</option></select></td><td><input type="submit" class="btn btn-primary" name="update" value="Update"/></td></tr></table>
<br>
									<table id = "table" class = "table table-bordered" >	
			<thead>
				<tr>
					<th><input type='checkbox'  value='' name='check_all' id='checkall' /></th>
					<th>Name</th>
					<th>Contact no</th>
					<th>Email</th>
					<th>Amount</th>
					<th>Order #</th>
					<th>Date</th>
					<th>Assign to</th>
					<th>Address</th>
					<th>Status</th>
					<th>Actions</th>
					
				</tr>
			</thead>
			
		
		<tbody>	
				<?php

					 while ($row = mysql_fetch_row($result)) {
						 echo "<tr><td><input type='checkbox' class='checkthis' id='test'  name='name[]'  value='$row[0]'/></td><td>$row[1]</td><td>$row[2]</td><td>$row[3]</td><td>$row[4]</td>
<td>$row[5]</td><td>$row[6]</td><td>$row[7]</td><td>$row[8]</td><td>$row[9]</td><td>
<a  href='editorder.php?cid=$row[0]'   name='update' class='btn btn-warning btn-xs' > 
                           <span class='glyphicon glyphicon-edit' aria-hidden='true'></span>
                        </a>  |  <a  href='del_order.php?cid=$row[0]' class='btn btn-danger btn-xs'>
                          
                           <span class='glyphicon glyphicon-trash' aria-hidden='true'></span>
                        </a></td></tr>	";


					}
				
				?>
					</tbody>
		</table>
	</form>
															</div>

															<div id="profile" class="tab-pane">
																									
						 <form name="actionForm" action="updatestatus1.php" method="post" /><table ><tr>
					 	<td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td><select name="status[]" class="form-control" required><option value="">Bulk actions</option><option value="Delivered">Delivered</option><option value="In transit">Dispatch</option>
<option value="Returned">Returned</option></select></td><td><input type="submit" class="btn btn-primary" name="update" value="Update"/></td></tr></table>
<br>
									<table id = "table1" class = "table table-bordered" >	
			<thead>
				<tr>
					<th><input type='checkbox'  value='' name='check_all' id='checkall' /></th>
					<th>Name</th>
					<th>Contact no</th>
					<th>Email</th>
					<th>Amount</th>
					<th>Order #</th>
					<th>Date</th>
					<th>Assign to</th>
					<th>Address</th>
					<th>Status</th>
					<th>Actions</th>
					
				</tr>
			</thead>
			
		
		<tbody>	
				<?php
		
					 while ($row = mysql_fetch_row($result1)) {
						 echo "<tr><td><input type='checkbox' class='checkthis' id='test'  name='name[]'  value='$row[0]'/></td><td>$row[1]</td><td>$row[2]</td><td>$row[3]</td><td>$row[4]</td>
<td>$row[5]</td><td>$row[6]</td><td>$row[7]</td><td>$row[8]</td><td>$row[9]</td><td>
<a  href='editorder.php?cid=$row[0]'   name='update' class='btn btn-warning btn-xs' > 
                           <span class='glyphicon glyphicon-edit' aria-hidden='true'></span>
                        </a>  |  <a  href='del_order.php?cid=$row[0]' class='btn btn-danger btn-xs'>
                          
                           <span class='glyphicon glyphicon-trash' aria-hidden='true'></span>
                        </a></td></tr>	";


					}
				
				?>
					</tbody>
		</table>
	</form>
															</div>

															<div id="info" class="tab-pane">
																											
						 <form name="actionForm" action="updatestatus1.php" method="post" >
                                                                <table ><tr>
					 	<td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td style="border: none;"></td><td><select name="status[]" class="form-control" required><option value="">Bulk actions</option><option value="Delivered">Delivered</option><option value="In transit">Dispatch</option>
<option value="Returned">Returned</option></select></td><td><input type="submit" class="btn btn-primary" name="update" value="Update"/></td></tr></table>
<br>
									<table id = "table2" class = "table table-bordered" >	
			<thead>
				<tr>
					<th><input type='checkbox'  value='' name='check_all' id='checkall' /></th>
					<th>Name</th>
					<th>Contact no</th>
					<th>Email</th>
					<th>Amount</th>
					<th>Order #</th>
					<th>Date</th>
					<th>Assign to</th>
					<th>Address</th>
					<th>Status</th>
					<th>Actions</th>
					
				</tr>
			</thead>
			
		
		<tbody>	
				<?php
		
					 while ($row = mysql_fetch_row($result2)) {
						 echo "<tr><td><input type='checkbox' class='checkthis' id='test'  name='name[]'  value='$row[0]'/></td><td>$row[1]</td><td>$row[2]</td><td>$row[3]</td><td>$row[4]</td>
<td>$row[5]</td><td>$row[6]</td><td>$row[7]</td><td>$row[8]</td><td>$row[9]</td><td>
<a  href='editorder.php?cid=$row[0]'   name='update' class='btn btn-warning btn-xs' > 
                           <span class='glyphicon glyphicon-edit' aria-hidden='true'></span>
                        </a>  |  <a  href='del_order.php?cid=$row[0]' class='btn btn-danger btn-xs'>
                          
                           <span class='glyphicon glyphicon-trash' aria-hidden='true'></span>
                        </a></td></tr>	";


					}
				
				?>
					</tbody>
		</table>
	</form>
															</div>
<div id="date" class="tab-pane">
    <div class = "form-inline">
        <label>Date:</label>
        <input type = "text" class = "form-control" placeholder = "Start"  id = "date1"/>
        <label>To</label>
        <input type = "text" class = "form-control" placeholder = "End"  id = "date2"/>
        <button type = "button" class = "btn btn-primary" id = "btn_search"><span class = "glyphicon glyphicon-search"></span></button> <button type = "button" id = "reset" class = "btn btn-success"><span class = "glyphicon glyphicon-refresh"><span></button>
    </div>
    <br /><br />
    <div class = "table-responsive">
        <table id = "table3" class = "table table-borderedssss">
            <thead>
            <tr>
                <th><input type='checkbox'  value='' name='check_all' id='checkall' /></th>
                <th>Name</th>
                <th>Contact no</th>
                <th>Email</th>
                <th>Amount</th>
                <th>Order #</th>
                <th>Date</th>
                <th>Assign to</th>
                <th>Address</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
            </thead>
            <tbody id = "load_data">
            <?php
            $sql4="select * from courier_table ";
            $result3 = mysql_query($sql4, $con);
            while ($row = mysql_fetch_row($result3)) {
                ?>
                <tr>

                    <?php
                    echo "<td><input type='checkbox' class='checkthis' id='test'  name='name[]'  value='$row[0]'/></td><td>$row[1]</td><td>$row[2]</td><td>$row[3]</td><td>$row[4]</td>
                                    <td>$row[5]</td><td>$row[6]</td><td>$row[7]</td><td>$row[8]</td><td>$row[9]</td><td>
                                        <a  href='editorder.php?cid=$row[0]'   name='update' class='btn btn-warning btn-xs' >
                                            <span class='glyphicon glyphicon-edit' aria-hidden='true'></span>
                                        </a>  |  <a  href='del_order.php?cid=$row[0]' class='btn btn-danger btn-xs'>

                                            <span class='glyphicon glyphicon-trash' aria-hidden='true'></span>
                                        </a></td>	";
                    ?>					</tr>
                <?php
            }
            ?>
            </tbody>
        </table>
    </div>

</div>
															</div>
													</div>
												</div>
											</div>
       

	</div>

<script type="text/javascript">
    function deleteConfirm(){
        var result = confirm("Do you really want to delete records?");
        if(result){
            return true;
        }else{
            return false;
        }
    }
    $(document).ready(function(){
        $('#check_all').on('click',function(){
            if(this.checked){
                $('.checkbox').each(function(){
                    this.checked = true;
                });
            }else{
                $('.checkbox').each(function(){
                    this.checked = false;
                });
            }
        });

        $('.checkbox').on('click',function(){
            if($('.checkbox:checked').length == $('.checkbox').length){
                $('#check_all').prop('checked',true);
            }else{
                $('#check_all').prop('checked',false);
            }
        });
    });
</script>




</body>
</html>

<script src = "jquery-3.2.1.js"></script>
<script src = "jquery.dataTables.js"></script>
<script src = "jquery-ui.js"></script>
<script src = "ajax.js"></script>
<script type = "text/javascript">
	$(document).ready(function(){
		  $('#table').DataTable();
	});
    $(document).ready(function(){
        $('#table1').DataTable();
    });
    $(document).ready(function(){
        $('#table2').DataTable();
    });
    $(document).ready(function(){
        $('#table3').DataTable();
    });
</script>





</html>