<?php include('header.php')?>
<style>
    .dropbtn {
        background-color: white;
        color: #000000;
        padding: 10px;
        font-size: 16px;
        border: #000000 thick;
        cursor: pointer;
    }

    .dropdown {
        position: relative;
        display: inline-block;
    }

    .dropdown-content {
        display: none;
        position: absolute;
        background-color: #f9f9f9;
        min-width: 160px;
        box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
        z-index: 1;
    }

    .dropdown-content a {
        color: black;
        padding: 12px 16px;
        text-decoration: none;
        display: block;
    }

    .dropdown-content a:hover {background-color: #f1f1f1}

    .dropdown:hover .dropdown-content {
        display: block;
    }

    .dropdown:hover .dropbtn {
        background-color: whitesmoke;
    }
</style>

<div id="" class="user-dashboard" style="margin-top: -350px">
    <div class="row">
        <div class="col-lg-2 col-md-2 col-sm-2">
        </div>
        <div class="col-lg-10 col-md-10 col-sm-10">
            <?php
            include "connect.php";
            if (!isset($_GET['startrow']) or !is_numeric($_GET['startrow'])) {
                //we give the value of the starting row to 0 because nothing was found in URL
                $startrow = 0;
//otherwise we take the value from the URL
            } else {
                $startrow = (int)$_GET['startrow'];
            }
            // $sql1="select * from courier_table WHERE  date BETWEEN DATE_SUB(NOW(), INTERVAL 30 DAY) AND NOW();  /* where `status`='Paid'*/";
            $sql1="select * from  courier_table WHERE date < DATE_SUB(DATE(NOW()), INTERVAL 1 MONTH)
ORDER BY date DESC";
            // $sql2="select * from courier_table where `status`='Pending'";
            // $sql3="select * from courier_table where `status`='Delivered'";
            $sql4 = "select * from courier_table WHERE date < DATE_SUB(DATE(NOW()), INTERVAL 1 MONTH)";
            $result1 = mysql_query($sql1, $con);
            // $result2=mysql_query($sql2,$con);
            // $result3=mysql_query($sql3,$con);
            $result4 = mysql_query($sql4, $con);
            // include("report1.php");
            if (!$result4) {
                echo "Error!" . "</br>";
                //       include 'report.php';
            } else {
                $sum = 0;
                while ($row = mysql_fetch_assoc($result4)) {
                    $sum += $row['amount'];
                }

            }
            if (!$result1) {
                echo "Error!" . "</br>";
                include 'report.php';
            } else {

                echo "<div class='panel panel-default'><div class='panel panel-heading'>";

                echo "<form name='actionForm' action='edit.php' method='post' />";
                echo "<table><tr><td><button class='btn btn-success'> Total Revenue: $sum UAE </button></td><td><select name='type' class='form-control' required><option value=''>Bulk actions</option><option value='chnge_status'>Change status</option><option value='edit_order'>Edit Order</option>
<option value='c_name'>Courier Name</option></select></td>";
                echo "<td><input type='submit' class='btn btn-primary' name='btn_delete' value='Update'/></td><td>
<div class='dropdown'>
  <button class='dropbtn'>All Dates</button>
  <div class='dropdown-content'>
    <ul>
    <li><a href='all_orders.php'>All Orders</a></li>
    <li><a href='this_month.php'>This Month</a></li>
    <li><a href='last_month.php'>Last Month</a></li>
    <li><a href='#' data-toggle='modal' data-target='#date'>Select Date</a></li>
  </ul>
</div>
</td>

<td><input type='search' id='search' placeholder='Type to search' class='form-control'></td><td><a href='addc.php' class='btn btn-primary btn-block'>Add Order</a></td></tr></table></div>";
                echo "<div class='table-responsive'>";
                echo "<table id='mytable' class='table table-bordred table-striped'> ";
                echo "<thead>  <th><input type='checkbox'  value='' name='check_all' id='checkall' /></th><th>Name </th><th>Contact_No </th><th>Email </th><th>Amount</th><th> Order # </th><th>Date </th>
<th>Assign to </th><th> Address </th><th>Status</th><th>Actions</th></thead>";
                while ($row = mysql_fetch_row($result1)) {


                    echo "<tfoot><tr><td><input type='checkbox' class='checkthis' id='test'  name='name[]'  value='$row[0]'/></td><td>$row[1]</td><td>$row[2]</td><td>$row[3]</td><td>$row[4]</td>
<td>$row[5]</td><td>$row[6]</td><td>$row[7]</td><td>$row[8]</td><td>$row[9]</td><td>
<a  href='editorder.php?cid=$row[0]'   name='update' class='btn btn-warning btn-xs' > Edit
                           <span class='glyphicon glyphicon-edit' aria-hidden='true'></span>
                        </a>  |  <a  href='del_order.php?cid=$row[0]' class='btn btn-danger btn-xs'>
                           Delete
                           <span class='glyphicon glyphicon-trash' aria-hidden='true'></span>
                        </a></td></tr></tfoot>";


                }
                echo "</table>";
                echo "</div></div>";

                echo "<div class='clearfix'></div>
<div class=' panel-footer'>

</div>";

                echo "</form>";
                echo "</br>";
                echo "<div id='date' class='modal fade' role='dialog'>
  <div class='modal-dialog'>
    <!-- Modal content-->
    <div class='modal-content'>
      <div class='modal-header'>
        <button type='button' class='close' data-dismiss='modal' >&times;</button>
        <h4 class='modal-title'>Modal Header</h4>
      </div>
      <div class='modal-body'>
       <form action='date.php' method='post'>
        
                           <div class='col-lg-12 col-sm-12 col-md-12 col-xs-12'>
                            <label for='name'>End date</label>
                            <input class='form-control' id='date' name='date' placeholder='MM/DD/YYYY' type='text'/>
                        </div>
                           <div class='col-lg-12 col-sm-12 col-md-12 col-xs-12'>
                          
                            <input type='submit' name='submit' value='Search' class='btn btn-primary'>
                        </div>
</form>
      </div>
      <div class='modal-footer'>
        <button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
      </div>
    </div>
  </div>
</div>";
            }
            echo '<a href="'.$_SERVER['PHP_SELF'].'?startrow='.($startrow+10).'">Next</a>';

            $prev = $startrow - 10;

            //only print a "Previous" link if a "Next" was clicked
            if ($prev >= 0)
                echo '<a href="'.$_SERVER['PHP_SELF'].'?startrow='.$prev.'">Previous</a>';
            //////////////////////
            /*
            if(!$result2)
            {
                echo "Error!" . "</br>";
                include 'report.php';
            }
            else {
                echo "<div class='container'>";
                echo "Couriers in 'Pending' state-->";echo "</br>";echo "</br>";
                echo "<table>";

                echo"<thead><th>Id</th><th>Sender's city </th><th>Reciever's address </th><th>Sender's name </th><th> Reciever's name </th><th> Reciever's address </th><th>Date </th><th> Rate
            </th><th>Mode </th><th>Status</th><th>Actions</th></thead>";
                while( $row=mysql_fetch_row($result2))
                {	echo "<tr><td>$row[0]</td><td>$row[1]</td><td>$row[2]</td><td>$row[3]</td><td>$row[4]</td>
            <td>$row[5]</td><td>$row[6]</td><td>$row[7]</td><td>$row[8]</td><td>$row[9]</td><td><a href=''><i class='fa fa-pencil-square-o'></i> </a> | <a href='' ><i class='fa fa-trash'> </td></tr>";


                }
                echo "</table>";echo "</div>";echo "</br>"; }
            //////////////////////////////

            if(!$result3)
            {
                echo "Error!" . "</br>";
                include 'report.php';
            }
            else {
                echo "<div class='container'>";

                echo "Couriers in 'Delivered' state-->";echo "</br>";echo "</br>";
                echo "<table>";

                echo"<thead><th>Id</th><th>Sender's city </th><th>Reciever's address </th><th>Sender's name </th><th> Reciever's name </th><th> Reciever's address </th><th>Date </th><th> Rate
            </th><th>Mode </th><th>Status</th><th>Actions</th></thead>";
                while( $row=mysql_fetch_row($result3))
                {
                    echo "<tr><td>$row[0]</td><td>$row[1]</td><td>$row[2]</td><td>$row[3]</td><td>$row[4]</td>
            <td>$row[5]</td><td>$row[6]</td><td>$row[7]</td><td>$row[8]</td><td>$row[9]</td><td><a href='update.php'><i class='fa fa-pencil-square-o'></i> </a> | <a href='' ><i class='fa fa-trash'> </td></tr>";



                }
                echo "</table>";
                echo "</div>";}
            /////////////////////

            */



            ?>
        </div>
    </div>
</div>
<!-- END of home -->




<body>

<!-- Extra JavaScript/CSS added manually in "Settings" tab -->
<!-- Include jQuery -->
<script type="text/javascript" src="https://code.jquery.com/jquery-1.11.3.min.js"></script>

<!-- Include Date Range Picker -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/js/bootstrap-datepicker.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/css/bootstrap-datepicker3.css"/>

<script>
    $(document).ready(function(){
        var date_input=$('input[name="date"]'); //our date input has the name "date"
        var container=$('.bootstrap-iso form').length>0 ? $('.bootstrap-iso form').parent() : "body";
        date_input.datepicker({
            format: 'mm/dd/yyyy',
            container: container,
            todayHighlight: true,
            autoclose: true,
        })
    })
</script>
</body>
</html>