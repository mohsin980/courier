<div class="side-menu-container">
    <nav class="navbar navbar-default">
    <ul class="nav navbar-nav">
        <li class="active"><a href="#"><span class="glyphicon glyphicon-dashboard"></span> Dashboard</a></li>
        <li><a href="add_user.php"><span class="glyphicon glyphicon-plane"></span> Add User</a></li>
        <li><a href="viewemp.php"><span class="glyphicon glyphicon-plane"></span> View Users</a></li>
        <li><a href="rememp.php"><span class="glyphicon glyphicon-plane"></span>  Remove Users</a></li>
        <li><a href="addc.php"><span class="glyphicon glyphicon-plane"></span>  Add Order</a></li>
        <li><a href="rememp.php"><span class="glyphicon glyphicon-plane"></span>  View Orders</a></li>
        <li><a href="logout.php"><span class="glyphicon glyphicon-plane"></span>  Logout</a></li>

    </ul>
    </nav>
</div>