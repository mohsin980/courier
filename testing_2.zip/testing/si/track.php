<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>SidEx - Courier Management System</title>
</head>

<body>
<?php

$con=mysql_connect("localhost","root","");
if(!$con)
{
    die('could not connect'.mysql_error());
}
mysql_select_db("courier",$con);
// $sql1="select * from courier_table WHERE  date BETWEEN DATE_SUB(NOW(), INTERVAL 30 DAY) AND NOW();  /* where `status`='Paid'*/";
$sql1="select * from  courier_table WHERE date > DATE_SUB(DATE(NOW()), INTERVAL 1 MONTH) 
ORDER BY date DESC";
// $sql2="select * from courier_table where `status`='Pending'";
// $sql3="select * from courier_table where `status`='Delivered'";
$sql4="select * from courier_table";
$result1=mysql_query($sql1,$con);
// $result2=mysql_query($sql2,$con);
// $result3=mysql_query($sql3,$con);
$result4=mysql_query($sql4,$con);
include("report1.php");
if(!$result1)
{
    echo "Error!" . "</br>";
    include 'report.php';
}
else {
    echo "<table><tr><td><form action='' method='post'>
 <td><select name='' class='form-control'><option>Bulk Actions</option><option>Change Status</option>
<option>Edit Order</option><option>Courier name</option></select></td><td>
<input type='button' class='btn btn-default' name='bulk' value='APPLY'></td></form></td>
<td><form action='' method='post'>
<td><div class='dropdown'>
  <button class='dropbtn'>All Dates</button>
  <div class='dropdown-content'>
    <ul>
    <li><a href='all_orders.php'>All Orders</a></li>
    <li><a href='this_month.php'>This Month</a></li>
    <li><a href='last_month.php'>Last Month</a></li>
    <li><a href='custom_date.php'>Select Date</a></li>
  </ul>
</div></td>
<td>
<form action='result.php' method='post'>
<td><input type='text' name='search' placeholder='Search for a customer' class='form-control'></td>
<td><input type='submit' class='btn btn-default' value='Filter'  name='filter'></td>
</form></td><td> <button class=\"btn btn-box-tool\" data-widget=\"collapse\" data-toggle=\"tooltip\" title=\"Collapse\"><i class=\"fa fa-minus\"></i></button>
                <button class=\"btn btn-box-tool\" data-widget=\"remove\" data-toggle=\"tooltip\" title=\"Remove\"><i class=\"fa fa-times\"></i></button></td></tr></table>";
    echo "";
    echo "<table>";
    echo "<thead><th></th><th>Name </th><th>Contact_No </th><th>Email </th><th>Amount</th><th> Order # </th><th>Date </th>
<th>Assign to </th><th> Address </th><th>Status</th><th>Actions</th></thead>";
    while ($row = mysql_fetch_row($result1)) {

        echo "<tr><td><input type='checkbox' name='name1' '.($row[0] == 1 ? 'checked' : '').' value='1'/></td><td>$row[1]</td><td>$row[2]</td><td>$row[3]</td><td>$row[4]</td>
<td>$row[5]</td><td>$row[6]</td><td>$row[7]</td><td>$row[8]</td><td>$row[9]</td><td>
<button type='button' data-toggle='modal' data-target='#$row[0]'   name='edit' class='btn btn-warning btn-xs' > Edit
                           <span class='glyphicon glyphicon-edit' aria-hidden='true'></span>
                        </button>  |  <a  type='button' class='btn btn-danger btn-xs'>
                           Delete
                           <span class='glyphicon glyphicon-trash' aria-hidden='true'></span>
                        </a></td></tr>";


    }
    echo "</table>";
    echo "</br>";
    echo "<div id='$row[0]' class='modal fade' role='dialog'>
  <div class='modal-dialog'>
    <!-- Modal content-->
    <div class='modal-content'>
      <div class='modal-header'>
        <button type='button' class='close' data-dismiss='modal' >&times;</button>
        <h4 class='modal-title'>Modal Header</h4>
      </div>
      <div class='modal-body'>
        <p>Some text in the modal.</p>
      </div>
      <div class='modal-footer'>
        <button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
      </div>
    </div>
  </div>
</div>";
}
//////////////////////
/*
if(!$result2)
{
    echo "Error!" . "</br>";
    include 'report.php';
}
else {
    echo "<div class='container'>";
    echo "Couriers in 'Pending' state-->";echo "</br>";echo "</br>";
    echo "<table>";

    echo"<thead><th>Id</th><th>Sender's city </th><th>Reciever's address </th><th>Sender's name </th><th> Reciever's name </th><th> Reciever's address </th><th>Date </th><th> Rate
</th><th>Mode </th><th>Status</th><th>Actions</th></thead>";
    while( $row=mysql_fetch_row($result2))
    {	echo "<tr><td>$row[0]</td><td>$row[1]</td><td>$row[2]</td><td>$row[3]</td><td>$row[4]</td>
<td>$row[5]</td><td>$row[6]</td><td>$row[7]</td><td>$row[8]</td><td>$row[9]</td><td><a href=''><i class='fa fa-pencil-square-o'></i> </a> | <a href='' ><i class='fa fa-trash'> </td></tr>";


    }
    echo "</table>";echo "</div>";echo "</br>"; }
//////////////////////////////

if(!$result3)
{
    echo "Error!" . "</br>";
    include 'report.php';
}
else {
    echo "<div class='container'>";

    echo "Couriers in 'Delivered' state-->";echo "</br>";echo "</br>";
    echo "<table>";

    echo"<thead><th>Id</th><th>Sender's city </th><th>Reciever's address </th><th>Sender's name </th><th> Reciever's name </th><th> Reciever's address </th><th>Date </th><th> Rate
</th><th>Mode </th><th>Status</th><th>Actions</th></thead>";
    while( $row=mysql_fetch_row($result3))
    {
        echo "<tr><td>$row[0]</td><td>$row[1]</td><td>$row[2]</td><td>$row[3]</td><td>$row[4]</td>
<td>$row[5]</td><td>$row[6]</td><td>$row[7]</td><td>$row[8]</td><td>$row[9]</td><td><a href='update.php'><i class='fa fa-pencil-square-o'></i> </a> | <a href='' ><i class='fa fa-trash'> </td></tr>";



    }
    echo "</table>";
    echo "</div>";}
/////////////////////

*/
if(!$result4)
{
    echo "Error!" . "</br>";
    include 'report.php';
}
else {
    echo "<div class='container'>";
    echo "</br>";echo "</br>";echo "Total Revenue-->> &#x20B9; ";
    $sum = 0;
    while ($row = mysql_fetch_assoc($result4))
    {
        $sum += $row['amount'];
    }

    echo $sum;

    echo "</br>";echo "</div>"; }



?>
		<?php
        
			$con=mysql_connect("localhost","root","");
			if(!$con)
			{
			die('could not connect'.mysql_error());
			}
			
			mysql_select_db("courier",$con);
			
			
			$un=$_POST['username'];
			$cid=$_POST['cid'];
			
			$sql="select * from courier_table where sname='$un' and cid='$cid'";
			
			
			
			$result=mysql_query($sql,$con);
			include("report3.php");
			if(!$result)
			{
			echo "Incorrect details !" . "</br>";
			include 'courier_boy.php';
			}
			else {
			
			echo "<table>";
			
			while( $row=mysql_fetch_row($result))
			{
				echo "<thead><th>Courier id</th><th>Sender's name</th><th>Status</th></thead>";
				echo "<td>$row[0]</td><td>$row[3]</td><td>$row[9]</td>";
			}
			echo "</table>"; }
        ?>

</body>
</html>
