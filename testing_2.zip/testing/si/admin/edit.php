<?php
 switch($_POST['type'])
  {
      case "chnge_status":
         include "updatestatus.php";
          break;
      case "edit_order":
              include 'edit_orders.php';
          break;
      case "c_name":
      include "update.php";
          break;
  }

?>