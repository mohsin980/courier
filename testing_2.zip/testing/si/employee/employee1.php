
<!------------------------------------------>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>


    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Employee_Session</title>
    <meta name="keywords" content="" />
    <meta name="description" content="" />

    <link href="templatemo_style.css" type="text/css" rel="stylesheet" />
    <link href="css/style.css" type="text/css" rel="stylesheet" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script type="text/javascript" src="js/nav.js"></script>
    <script type="text/javascript" src="js/jquery.scrollTo-min.js"></script>
    <script type="text/javascript" src="js/jquery.localscroll-min.js"></script>
    <script type="text/javascript" src="js/init.js"></script>
    <link rel="stylesheet" href="css/slimbox2.css" type="text/css" media="screen" />

    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-T8Gy5hrqNKT+hzMclPo118YTQO6cYprQmhrYwIiQ/3axmI1hQomh7Ud2hPOy8SP1" crossorigin="anonymous">
    <script type="text/JavaScript" src="js/slimbox2.js"></script>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <script src="http://getbootstrap.com/dist/js/bootstrap.min.js"></script>
    <style>
        table {
            font-family: arial, sans-serif;
            border-collapse: collapse;
            width: 100%;
        }

        td, th {
            border: 1px solid #dddddd;
            text-align: left;
            padding: 8px;
        }

        tr:nth-child(even) {
            background-color: #dddddd;
        }
        .form-group input[type="checkbox"] {
            display: none;
        }

        .form-group input[type="checkbox"] + .btn-group > label span {
            width: 20px;
        }

        .form-group input[type="checkbox"] + .btn-group > label span:first-child {
            display: none;
        }
        .form-group input[type="checkbox"] + .btn-group > label span:last-child {
            display: inline-block;
        }

        .form-group input[type="checkbox"]:checked + .btn-group > label span:first-child {
            display: inline-block;
        }
        .form-group input[type="checkbox"]:checked + .btn-group > label span:last-child {
            display: none;
        }
    </style>
    <script type="text/javascript"
    <script type="text/javascript">
        <!--
        function MM_validateForm() { //v4.0
            if (document.getElementById){
                var i,p,q,nm,test,num,min,max,errors='',args=MM_validateForm.arguments;
                for (i=0; i<(args.length-2); i+=3) { test=args[i+2]; val=document.getElementById(args[i]);
                    if (val) { nm=val.name; if ((val=val.value)!="") {
                        if (test.indexOf('isEmail')!=-1) { p=val.indexOf('@');
                            if (p<1 || p==(val.length-1)) errors+='- '+nm+' must contain an e-mail address.\n';
                        } else if (test!='R') { num = parseFloat(val);
                            if (isNaN(val)) errors+='- '+nm+' must contain a number.\n';
                            if (test.indexOf('inRange') != -1) { p=test.indexOf(':');
                                min=test.substring(8,p); max=test.substring(p+1);
                                if (num<min || max<num) errors+='- '+nm+' must contain a number between '+min+' and '+max+'.\n';
                            } } } else if (test.charAt(0) == 'R') errors += '- '+nm+' is required.\n'; }
                } if (errors) alert('The following error(s) occurred:\n'+errors);
                document.MM_returnValue = (errors == '');
            } }
        //-->
    </script>
    <script type="text/javascript">$(document).ready(function(){
            $("#mytable #checkall").click(function () {
                if ($("#mytable #checkall").is(':checked')) {
                    $("#mytable input[type=checkbox]").each(function () {
                        $(this).prop("checked", true);
                    });

                } else {
                    $("#mytable input[type=checkbox]").each(function () {
                        $(this).prop("checked", false);
                    });
                }
            });

            $("[data-toggle=tooltip]").tooltip();
        });
    </script>
    <style type="text/css">
        /*Main CSS*/


        /*Login Signup Page*/
        a:focus,a:hover,a{
            outline:none;
            text-decoration: none;
        }
        li,ul{
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .header-top i {
            font-size: 18px;
        }
        .bg-image {
            background: url(../images/background-login.jpg) no-repeat 0 0 / cover;
            position: relative;
            width: 100%;
            height: 100vh;
            display: table;
        }

        .login-header {
            display: inline-block;
            width: 100%;
            background: #0e1a35;
        }

        .login-signup {
            display: table-cell;
            vertical-align: middle;
            width: 100%;
        }

        .login-logo img {
            cursor: pointer;
            max-width: 171px;
            padding: 23px 15px 22px;
            width: 100%;
        }

        .login-header .navbar-right {
            margin-right: 0px;
        }

        .login-header .nav-tabs > li.active > a,
        .login-header .nav-tabs > li.active > a:focus,
        .login-header .nav-tabs > li.active > a:hover {
            background-color: transparent;
            border: none;
            color: #fff;
        }

        .login-header .nav-tabs > li > a {
            border: medium none;
            border-radius: 0;
            font-size: 14px;
            font-weight: 500;
            line-height: 48px;
            padding: 15px 30px;
            color: #fff;
        }

        .login-header .nav-tabs {
            border-bottom: none;
        }

        .login-header .nav-tabs > li {
            margin-bottom: 0px;
        }

        .login-header .nav > li > a:focus,
        .login-header .nav > li > a:hover {
            background: none;
            text-decoration: none;
        }

        .login-header .nav-tabs > li.active {
            border-bottom: 6px solid #5584ff;
        }

        .login-inner h1 {
            color: #8492af;
            font-size: 48px;
            font-weight: 300;
            text-align: center;
            margin-top: 0;
            margin-bottom: 20px;
        }

        .login-inner h1 span {
            color: #5584ff;
        }

        .login-form {
            text-align: center;
        }

        .login-form input {
            -moz-border-bottom-colors: none;
            -moz-border-left-colors: none;
            -moz-border-right-colors: none;
            -moz-border-top-colors: none;
            background: rgba(0, 0, 0, 0) none repeat scroll 0 0;
            border-color: -moz-use-text-color -moz-use-text-color #d4d9e3;
            border-image: none;
            border-style: none none solid;
            border-width: medium medium 1px;
            font-size: 13px;
            font-weight: 300;
            width: 100%;
            color: #8492af;
            padding: 15px 50px;
            font-size: 17px;
            max-width: 550px;
        }

        .login-form label {
            margin-bottom: 30px;
            width: 100%;
        }

        .user input {
            background: rgba(0, 0, 0, 0) url("../images/user.png") no-repeat scroll 7px 12px;
        }

        .pass input {
            background: rgba(0, 0, 0, 0) url("../images/password.png") no-repeat scroll 7px 12px;
        }

        .mail input {
            background: rgba(0, 0, 0, 0) url("../images/mail.png") no-repeat scroll 4px 12px;
        }

        .login-signup .tab-content {
            background: #ffffff none repeat scroll 0 0;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.176);
            display: inline-block;
            margin-top: -8px;
            width: 100%;
        }

        .form-btn {
            background: #5584ff none repeat scroll 0 0;
            border: medium none;
            border-radius: 100px;
            color: #ffffff;
            font-weight: 400;
            max-width: 250px;
            padding: 10px 0;
            position: relative;
            width: 100%;
            margin: 40px 0;
            box-shadow: 0 2px 8px #d2d2d2;
            -moz-box-shadow: 0 2px 8px #d2d2d2;
            -webkit-box-shadow: 0 2px 8px #d2d2d2;
        }

        .form-btn::before {
            content: "";
            font-family: FontAwesome;
            position: absolute;
            right: 17px;
            top: 9px;
        }

        .form-details {
            padding: 35px 0;
        }

        .tab-content .tab-pane {
            padding: 70px 0;
        }


        /*Login Signup Page*/


        /*Home Page*/

        .home {
            background: #f6f7fa;
        }

        #navigation {
            background: #0e1a35;
        }

        #navigation {
            padding: 0;
        }

        .display-table {
            display: table;
            padding: 0;
            height: 100%;
            width: 100%;
        }

        .display-table-row {
            display: table-row;
            height: 100%;
        }

        .display-table-cell {
            display: table-cell;
            float: none;
            height: 100%;
        }

        .v-align {
            vertical-align: top;
        }
        .logo img {
            max-width: 180px;
            padding: 16px 0 17px;
            width: 100%;
        }

        .header-top {
            margin: 0;
            padding-top: 2px;
        }

        .header-top img {
            border-radius: 50%;
            max-width: 48px !important;
            width: 100%;
        }

        .add-project {
            background: #5584ff none repeat scroll 0 0;
            border-radius: 100px;
            color: #ffffff;
            font-size: 14px;
            font-weight: 600;
            padding: 10px 27px 10px 45px;
            position: relative;
        }

        .header-rightside .nav > li > a:focus,
        .header-rightside .nav > li > a:hover {
            background: none;
            text-decoration: none;
        }

        .add-project::before {
            background: rgba(0, 0, 0, 0) url("../images/plus.png") no-repeat scroll 0 0;
            content: "";
        ;
            height: 12px;
            left: 17px;
            position: absolute;
            top: 12px;
            width: 12px;
        }

        .add-project:hover {
            color: #ffffff;
        }

        .header-top i {
            color: #0e1a35;
        }

        .icon-info {
            position: relative;
        }
        .navi i {
            font-size: 20px;
        }
        .label.label-primary {
            border-radius: 50%;
            font-size: 9px;
            left: 8px;
            position: absolute;
            top: -9px;
        }

        .icon-info .label {
            border: 2px solid #ffffff;
            font-weight: 500;
            padding: 3px 5px;
            text-align: center;
        }

        .header-top li {
            display: inline-block;
            text-align: center;
        }

        .header-top .dropdown-toggle {
            color: #0e1a35;
        }

        .header-top .dropdown-menu {
            border: medium none;
            left: -85px;
            padding: 17px;
        }
        .view {
            background: #5584ff none repeat scroll 0 0;
            border-radius: 100px;
            color: #ffffff;
            display: inline-block;
            font-size: 14px;
            font-weight: 600;
            margin-top: 10px;
            padding: 10px 15px;
        }

        .navbar-content > span {
            font-size: 13px;
            font-weight: 700;
        }

        .img-responsive {
            width: 100%;
        }
        #navigation{
            -webkit-transition: all 0.5s ease;
            -moz-transition: all 0.5s ease;
            -o-transition: all 0.5s ease;
            transition: all 0.5s ease;
        }
        .search input {
            border: none;
            font-size: 15px;
            padding: 15px 9px;
            width: 100%;
            background: rgba(0, 0, 0, 0) url("../images/search.png") no-repeat scroll 99% 12px;
            color: #8492af;
        }

        header {
            background: #ffffff none repeat scroll 0 0;
            box-shadow: 0 1px 12px rgba(0, 0, 0, 0.04);
            display: inline-block !important;
            line-height: 23px;
            padding: 15px;
            transition: all 0.5s ease 0s;
            width: 100%;
            -webkit-transition: all 0.5s ease;
            -moz-transition: all 0.5s ease;
            -o-transition: all 0.5s ease;
            transition: all 0.5s ease;
        }

        .logo {
            text-align: center;
        }

        .navi a {
            border-bottom: 1px solid #0d172e;
            border-top: 1px solid #0d172e;
            color: #ffffff;
            display: block;
            font-size: 17px;
            font-weight: 500;
            padding: 28px 20px;
            text-decoration: none;
        }

        .navi i {
            margin-right: 15px;
            color: #5584ff;
        }

        .navi .active a {
            background: #122143;
            border-left: 5px solid #5584ff;
            padding-left: 15px;
        }

        .navi a:hover {
            background: #122143 none repeat scroll 0 0;
            border-left: 5px solid #5584ff;
            display: block;
            padding-left: 15px;
        }

        .navbar-default {
            background-color: #ffffff;
            border-color: #ffffff;
        }

        .navbar-toggle {
            border: none;
        }

        .navbar-default .navbar-toggle:focus,
        .navbar-default .navbar-toggle:hover {
            background-color: rgba(0, 0, 0, 0);
        }

        .navbar-default .navbar-toggle .icon-bar {
            background-color: #0e1a35;
        }

        .circle-logo {
            margin: 0 auto;
            max-width: 30px !important;
            text-align: center;
        }
        .hidden-xs{
            -webkit-transition: all 0.5s ease;
            -moz-transition: all 0.5s ease;
            -o-transition: all 0.5s ease;
            transition: all 0.5s ease;
        }

        .user-dashboard {
            padding: 0 20px;
        }

        .user-dashboard h1 {
            color: #0e1a35;
            font-size: 30px;
            font-weight: 500;
            margin: 0;
            padding: 21px 0;
        }
        .sales {
            background: #ffffff none repeat scroll 0 0;
            border: 1px solid #d4d9e3;
            display: inline-block;
            padding: 15px;
            width: 100%;
        }
        .sales button {
            background: rgba(0, 0, 0, 0) none repeat scroll 0 0;
            border: 1px solid #dadee7;
            border-radius: 100px;
            font-size: 15px;
            letter-spacing: 0.5px;
            padding-right: 32px;
            color: #0e1a35;
        }

        .sales button::before {
            content: "";
            font-family: FontAwesome;
            position: absolute;
            right: 12px;
            top: 11px;
        }
        .sales  .btn-group {
            float: right;
        }
        .sales h2 {
            color: #8492af;
            float: left;
            font-size: 21px;
            font-weight: 600;
            margin: 0;
            padding: 9px 0 0;
        }
        .btn.btn-secondary.btn-lg.dropdown-toggle > span {
            font-size: 15px;
            font-weight: 600;
            letter-spacing: 0.5px;
        }
        .sales .dropdown-menu{
            margin: 0px;
            padding: 0px;
            border: 0px;
            border-radius: 8px;
            width: 100%;
            color: #0e1a35;
        }
        .sales .btn-group.open .dropdown-toggle, .btn.active, .btn:active{
            box-shadow: none;
        }
        .sales .dropdown-menu > a {
            color: #0e1a35;
            display: inline-block;
            font-weight: 800;
            padding: 9px 0;
            text-align: center;
            width: 100%;
        }
        #my-cool-chart svg {
            width: 100%;
        }
        .sales .dropdown-menu > a:hover{
            color: #5584FF;
        }
        .shield-buttons {
            display: none;
        }
        .close, .close:focus, .close:hover {
            color: #fff;;
            opacity: 1;
            text-shadow: none;
        }
        .modal-body input {
            border: 1px solid #d4d9e3;
            font-size: 14px;
            font-weight: 300;
            margin: 5px 0;
            padding: 14px 10px;
            width: 100%;
            color: #8492af;
        }
        .modal-body textarea {
            border: 1px solid #d4d9e3;
            font-size: 14px;
            font-weight: 300;
            height: 200px;
            margin-top: 5px;
            padding: 9px 10px;
            width: 100%;
            color: #8492af;
        }
        .modal-header.login-header h4 {
            color: #ffffff;
        }
        .modal-footer .add-project {
            background: #5584ff none repeat scroll 0 0;
            border: medium none;
            border-radius: 100px;
            color: #ffffff;
            font-size: 14px;
            font-weight: 600;
            padding: 10px 30px;
            position: relative;
        }
        .modal-footer .add-project::before{display: none;}
        .modal-footer {
            border: 0 none;
            padding: 10px 15px 26px;
            text-align: right;
        }
        .cancel {
            background: #0E1A35     ;
            border: medium none;
            border-radius: 100px;
            color: #ffffff;
            font-size: 14px;
            font-weight: 600;
            padding: 10px 30px;
            position: relative;

        }
        .modal{
            top: 20%;
        }
        .modal-header .close {
            margin-top: 2px;
        }
        .search input:focus{
            border-bottom: 1px solid #BDC4D4;
            line-height:22px;
            transition: 0.1s all;
        }
        .modal-header.login-header {
            border-top-left-radius: 5px;
            border-top-right-radius: 5px;
        /*Main CSS*/






        @media only screen and (max-device-width: 767px) {
            .login-logo img {
                margin: 0 auto;
            }
            .login-details .nav-tabs > li {
                text-align: center;
                width: 50%;
            }
            .login-signup .login-inner h1 {
                font-size: 26px;
                margin-bottom: 0;
                margin-top: 10px;
            }
            .login-inner .login-form input {
                font-size: 15px;
                max-width: 100%;
                padding: 15px 45px;
            }
            .login-inner .form-details {
                padding: 25px;
            }
            .login-inner .login-form label {
                margin-bottom: 20px;
                width: 100%;
            }
            .login-inner .form-btn {
                margin: 0;
                max-width: 180px;
            }
            .tab-content .tab-pane {
                padding: 20px 0;
            }
            #navigation .navi a {
                font-size: 14px;
                padding: 20px;
                text-align: center;
            }
            #navigation .navi i {
                margin-right: 0px;
            }
            #navigation .navi a:hover,
            #navigation .navi .active a {
                background: #122143 none repeat scroll 0 0;
                border-left: none;
                display: block;
                padding-left: 20px;
            }
            header .header-top img {
                max-width: 38px !important;
            }
            .v-align header {
                padding: 12px 15px;
            }
            header .header-top li {
                padding-left: 13px;
                padding-right: 6px;
            }
            .navbar-default .navbar-toggle {
                border-color: rgba(0, 0, 0, 0);
            }
            .navbar-header .navbar-toggle {
                float: left;
                margin: 0;
                padding: 0;
                top: 12px;
            }
            button,
            html [type="button"],
            [type="reset"],
            [type="submit"] {
                outline: medium none;
            }
            .user-dashboard .sales h2 {
                color: #8492af;
                float: left;
                font-size: 14px;
                font-weight: 600;
                margin: 0;
                padding: 13px 0 0;
            }
            .user-dashboard .btn.btn-secondary.btn-lg.dropdown-toggle > span {
                font-size: 11px;
            }
            .user-dashboard .sales button {
                font-size: 11px;
                padding-right: 23px;
            }
            .user-dashboard .sales h2 {
                font-size: 12px;
            }
            .gutter{
                padding: 0;
            }
        }

        @media only screen and (max-device-width: 992px) {
            header .header-top li {
                padding-left: 20px !important;
                padding-right: 0;
            }
            header .logo img {
                max-width: 125px !important;
            }

        }

        @media only screen and (min-device-width: 767px) and (max-device-width: 998px){
            .user-dashboard .header-top {
                padding-top: 5px;
            }
            .user-dashboard .header-rightside {
                display: inline-block;
                float: left;
                width: 100%;
            }
            .user-dashboard .header-rightside .header-top img {
                max-width: 41px !important;
            }
            .user-dashboard .sales button {
                font-size: 10px;
            }
            .user-dashboard .btn.btn-secondary.btn-lg.dropdown-toggle > span {
                font-size: 12px;
            }
            .user-dashboard .sales h2 {
                font-size: 15px;
            }
        }
        @media only screen and (min-device-width:998px) and (max-device-width: 1350px){
            #navigation .logo img {
                max-width: 130px;
                padding: 16px 0 17px;
                width: 100%;
            }
        }
    </style>
</head>
<body class="home">
<div class=" display-table">
    <div class="row display-table-row">
        <div class="col-md-2 col-sm-1 hidden-xs display-table-cell v-align box" id="navigation">
            <div class="logo">
                <a hef=""><h1>Welcome here</h1> </a>
            </div>
            <div class="navi">
                <ul>
                    <li class="active"><a href="employee/employee.php"><i class="fa fa-home" aria-hidden="true"></i><span class="hidden-xs hidden-sm">Dashboard</span></a></li>
                    <li><a href="employee/reporting.php"><i class="fa fa-tasks" aria-hidden="true"></i><span class="hidden-xs hidden-sm">Orders</span></a></li>
                    <li><a href="employee/logout.php"><i class="fa fa-power-off" aria-hidden="true"></i><span class="hidden-xs hidden-sm">Logout</span></a></li>

                </ul>
            </div>
        </div>
        <div class="col-md-10 col-sm-11 display-table-cell v-align">
            <!--<button type="button" class="slide-toggle">Slide Toggle</button> -->
            <div class="row">
                <header>
                    <div class="col-md-7">
                        <nav class="navbar-default pull-left">
                            <div class="navbar-header">
                                <button type="button" class="navbar-toggle collapsed" data-toggle="offcanvas" data-target="#side-menu" aria-expanded="false">
                                    <span class="sr-only">Toggle navigation</span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                            </div>
                        </nav>
                        <div class="search hidden-xs hidden-sm">
                            <strong><?php echo date("F j, Y, g:i a");?></strong></div>
                    </div>
                    <div class="col-md-5">
                        <div class="header-rightside">
                            <ul class="list-inline header-top pull-right">
                                <li>  </li>
                                <li class="hidden-xs"><a href="#" class="add-project" data-toggle="modal" data-target="#add_project">Add Order</a></li>
                                <li class="dropdown">
                                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><img src="http://jskrishna.com/work/merkury/images/user-pic.jpg" alt="Admin">
                                        <b class="caret"></b></a>
                                    <ul class="dropdown-menu">
                                        <li>
                                            <div class="navbar-content">
                                                <a href="logout" class="view btn-sm active">Logout</a>
                                            </div>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </div>
                </header>
            </div>

        </div></div>
</div>


<!-- Modal -->
<div id="add_project" class="modal fade" role="dialog">
    <div class="modal-dialog">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-header login-header">
                <button type="button" class="close" data-dismiss="modal">×</button>
                <h4 class="modal-title">Add Order</h4>
            </div>
            <div class="modal-body">
                <form action="addcourier.php" method="post"  >
                    <div class="col-lg-12 col-md-12 col-sm-12  col-xs-12">
                        <div class="panel panel-body">
                            <div class="col-lg-12 col-md-12 col-sm-12">
                                <label for="name">Name   :</label>
                                <input name="rname"  type="text " class="form-control" required>
                            </div>
                            <div class="col-lg-12 col-md-12 col-sm-12  col-xs-12">
                                <label for="name">Contact Number   :</label>
                                <input name="cno" id="orig"  type="TEXT" class="form-control" required>
                            </div>
                            <div class="col-lg-12 col-md-12 col-sm-12  col-xs-12">
                                <label for="address">Email  Address   :</label>
                                <input name="email" type="email"  id="saddress" class="form-control">
                            </div>
                            <div class="col-lg-12 col-md-12 col-sm-12  col-xs-12">
                                <label for="address">Amount   :</label>
                                <input name="amount" type="text"  id="saddress" class="form-control" required>

                            </div>
                            <div class="col-lg-12 col-md-12 col-sm-12  col-xs-12">
                                <label for="address">Order # :</label>
                                <input name="order_no" type="number"  id="saddress" class="form-control" required>

                            </div>
                            <div class="col-lg-12 col-md-12 col-sm-12  col-xs-12">
                                <label for="address"></label>
                                <input name="date" type="hidden"  id="saddress" class="form-control" required>

                            </div>
                            <div class="col-lg-12 col-md-12 col-sm-12">
                                <label for="address">  Address: </label>
                                <span class="REDLink">
                              <textarea name="address" cols="27" rows="2" id="raddress" class="form-control" required></textarea>

                            </div>
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

                                <label >Dispatch to:</label>
                                <select name="username" class="form-control" required>
                                    <?php  while( $row=mysql_fetch_row($result))
                                    { ?>

                                        <option value = "<?= $row[1] ?>"><?= $row[1] ?></option>
                                    <?php } ?>
                                </select>   </div>
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <label>Status</label>
                                <select name="status" class="form-control" required>
                                    <option>In Transist</option>
                                    <option>Delivered</option>
                                    <option>Returned</option>
                                </select>
                            </div>
                        </div>

                    </div>

                    <div class="col-lg-4 col-md-4 col-sm-4 col-sm-offset-4">


                    </div>

                </form>
            </div>
            <div class="modal-footer">
                <input align="right" name="pay" class="btn btn-success btn-block" type="submit" value="Add Courier" />

            </div>
        </div>

    </div>
</div>

<div  class="user-dashboard">
    <div class="container">
<div class="row">
    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 col-xss-12">
        </div>
    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 col-xss-12">
        <div class="panel panel-primary">
            <div class="panel-heading">Total Orders</div>
            <div class="panel panel-body">
                <?php
                include "connect.php";
                $sql1="select count(*) as total from courier_table ";
                $res = mysql_query($sql1,$con);
                while ($row = mysql_fetch_assoc($res))
                echo  "$row[total]";
                ?>
            </div>
        </div></div>
    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 col-xss-12">
        <div class="panel panel-primary">
            <div class="panel-heading">Users</div>
            <div class="panel panel-body">
                <?php
                include "connect.php";
                $sql1="select count(*) as total1 from users ";
                $res = mysql_query($sql1,$con);
                while ($row = mysql_fetch_assoc($res))

                    echo  "$row[total1]";
                ?>
            </div>
        </div></div>
    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 col-xss-12">
        <div class="panel panel-primary">
            <div class="panel-heading">Total Amount</div>
            <div class="panel panel-body">
                <?php
                $sql4 = "select * from courier_table";
                $result1 = mysql_query($sql1, $con);
                // $result2=mysql_query($sql2,$con);
                // $result3=mysql_query($sql3,$con);
                $result4 = mysql_query($sql4, $con);
                // include("report1.php");
                if (!$result4) {
                    echo "Error!" . "</br>";
                   // include 'report.php';
                } else {
                    $sum = 0;
                    while ($row = mysql_fetch_assoc($result4)) {
                        $sum += $row['amount'];
                    }

                    echo $sum;
}
?>
            </div>
        </div></div>
    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 col-xss-12">
    </div>
    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 col-xss-12">
        <div class="panel panel-success">
            <div class="panel-heading">Delivered Orders</div>
            <div class="panel panel-body">
                <?php
                include "connect.php";
                $sql1="select count(*) as total from courier_table WHERE status='delivered'";
                $res = mysql_query($sql1,$con);
                while ($row = mysql_fetch_assoc($res))
                    echo  "$row[total]";
                ?>
            </div>
        </div></div>
    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 col-xss-12">
        <div class="panel panel-primary">
            <div class="panel-heading">Dispatched Orders</div>
            <div class="panel panel-body">
                <?php
                include "connect.php";
                $sql1="select count(*) as total1 from courier_table WHERE status='In Transit' ";
                $res = mysql_query($sql1,$con);
                while ($row = mysql_fetch_assoc($res))

                    echo  "$row[total1]";
                ?>
            </div>
        </div></div>
    <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 col-xss-12">
        <div class="panel panel-danger">
            <div class="panel-heading">Returned Orders</div>
            <div class="panel panel-body">
                <?php
                include "connect.php";
                $sql1="select count(*) as total1 from courier_table WHERE status='Returned' ";
                $res = mysql_query($sql1,$con);
                while ($row = mysql_fetch_assoc($res))

                    echo  "$row[total1]";
                ?>
            </div>
        </div></div>
</div>
    </div>
            </div>
</body> <!-- END of home -->



