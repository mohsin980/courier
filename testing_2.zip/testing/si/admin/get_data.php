
<?php
$date1 = date("Y-m-d", strtotime($_POST['date1']));
$date2 = date("Y-m-d", strtotime($_POST['date2']));
$host='localhost';
$user='root';
$pass='';
$db='courier';
include "connect.php";
$q_book = "SELECT * FROM `courier_table` WHERE `date` BETWEEN '$date1' AND '$date2' ORDER BY `cid` ASC";
$result3 = mysql_query($q_book, $con);
$v_book = mysql_num_rows($result3);
if($v_book > 0){
    while ($row = mysql_fetch_row($result3)) {

        ?>
        <tr>
            <td><input type='checkbox' class='checkthis' id='test'  name='name[]'  value='<?= $row[0] ?>' /></td>
            <td><?php echo $row[1] ?></td>
            <td><?php echo $row[2] ?></td>
            <td><?php echo $row[3] ?></td>
            <td><?php echo $row[4] ?></td>
            <td><?php echo $row[5] ?></td>
            <td><?php echo date("m/d/Y", strtotime($row[6])) ?></td>
            <td><?php echo $row[7] ?></td>
            <td><?php echo $row[8] ?></td>
            <td><?php echo $row[9] ?></td>
            <td>
                <a  href='editorder.php?cid=<?= $row[0] ?>'   name='update' class='btn btn-warning btn-xs' >
                    <span class='glyphicon glyphicon-edit' aria-hidden='true'></span>
                </a>  |  <a  href='del_order.php?cid=<?= $row[0] ?>' class='btn btn-danger btn-xs'>

                    <span class='glyphicon glyphicon-trash' aria-hidden='true'></span>
                </a></td>
        </tr>
        <?php
    }
}else{
    echo '
		<tr>
			<td colspan = "4"><center>Record Not Found</center></td>
		</tr>
		';
}
?>