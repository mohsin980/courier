<?php

$con=mysql_connect("localhost","root","");
if(!$con)
{
    die('could not connect'.mysql_error());
}

mysql_select_db("courier",$con);



if($_POST['pay'])
{
   /* if(strcmp($_POST['mode'],'air')) $mode=100;
    else if(strcmp($_POST['mode'],'surface')) $mode=70;
    else $mode=50;
    $rate=$_POST['wt']*$_POST['num']*$mode;
   */
   $query="INSERT INTO `courier_table`(rname,cno,email,amount,order_no,address,username,status) 
VALUES ('$_POST[rname]','$_POST[cno]','$_POST[email]','$_POST[amount]','$_POST[order_no]','$_POST[address]','$_POST[username]','$_POST[status]')";
    $result=mysql_query($query,$con);
    if(!$result)
    {
        echo "Incorrect details !" . "</br>";
        include 'addc.php';
    }
    else {
        echo "<div class='container'>";
        echo " Courier Added Successfully !"."</br>";
        $query="select * from courier_table order by cid desc limit 1 ";
        $result=mysql_query($query,$con);
        $row=mysql_fetch_row($result);
        echo "Courier ID for tracking purposes: ->> ".$row[0];
        echo "</br>";
        echo "Amount to be paid: ->> &#x20B9;".$row[4];
        echo  "</div>";
        include 'addc.php';
    }

}

?>
