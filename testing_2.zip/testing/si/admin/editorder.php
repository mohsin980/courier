<?php include "header.php"; ?>
<?php
$cid = $_GET['cid'];
include("connect.php");
if(isset($_POST["update"]) && $_POST["update"]!="") {

        mysql_query("UPDATE courier_table set rname='" . $_POST["rname"] . "', cno='" . $_POST["cno"] . "', email='" .
            $_POST["email"] . "', amount='" . $_POST["amount"] . "',order_no='".$_POST['order_no']."',address='".$_POST['address']."',
            username='".$_POST['username']."',status='".$_POST['status']."'
             WHERE cid='" .$_POST['cid']. "'")  or die(mysql_error());
} ?>
    <div class="user-dashboard">
        <div >
            <div class="col-lg-6 col-md-6 col-sm-6 col-sm-offset-3">
                <div class="panel panel-primary">
                    <div class="panel panel-heading">
                        Update Courier Status
                    </div>
                    <div class="panel panel-body">
                        <?php   ?>
                        <form action="" method="post">

                            <?php
                                $sql1 = mysql_query("SELECT * FROM courier_table WHERE cid='$cid'") or die(mysql_error());
                             $row= mysql_fetch_array($sql1)
                                ?>
                                <div class="panel panel-body">
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        <label for="name">Name   :</label>
                                        <input type="hidden" name="cid" class="txtField" value="<?php echo $row[0]; ?>">
                                        <input name="rname" id="orig"  value="<?= $row[1] ?>" type="text " class="form-control" required>
                                    </div>
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        <label for="name">Contact Number   :</label>
                                        <input name="cno" id="orig"  value="<?= $row[2] ?>" type="TEXT" class="form-control" required>
                                    </div>
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        <label for="address">Email  Address   :</label>
                                        <input name="email" type="email" value="<?= $row[3] ?>"  id="saddress" class="form-control">
                                    </div>
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        <label for="address">Amount   :</label>
                                        <input name="amount" type="number" value="<?= $row[4] ?>"  id="saddress" class="form-control" required>

                                    </div>
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        <label >Order # :</label>
                                        <input name="order_no" type="number" value="<?= $row[5] ?>"   class="form-control" required>

                                    </div>
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        <label for="address"></label>
                                        <input name="date"  type="hidden"  id="saddress" class="form-control" required>

                                    </div>

                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

                                        <label >Dispatch to:</label>
                                        <select name="username" class="form-control" required>
                                            <option value="<?= $row[7] ?>"><?= $row[7] ?></option>
                                        </select>   </div>
                                    <div class="col-lg-12 col-md-12 col-sm-12">
                                        <label for="address">  Address: </label>
                                        <span class="REDLink">
                              <textarea name="address" cols="27" rows="2" id="raddress" value="<?= $row[8] ?>" class="form-control" required><?= $row[8] ?></textarea>

                                    </div>
                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                        <label>Status</label>
                                        <select name="status" class="form-control" required>
                                            <option value="In Transit" <?php if($row[9]=="")  echo 'selected="selected"';  ?>></option>
                                            <option value="In Transit" <?php if($row[9]=="In Transit")  echo 'selected="selected"';  ?>>In Transist</option>
                                            <option value="Delivered" <?php if($row[9]=="Delivered") echo 'selected="selected"';    ?>>Delivered</option>
                                            <option value="Returned" <?php if($row[9]=="Returned")  echo 'selected="selected"'; ?>>Returned</option>
                                        </select>
                                    </div>


                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <br>
                                <input type='submit' name='update' class="btn btn-primary btn-block" value='Update' />
                            </div>
                                </div>
                            <?php  ?>
                        </form>
                        <?php // } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php  ?>