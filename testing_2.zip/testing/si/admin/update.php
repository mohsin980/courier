<?php include('header.php') ?>
<?php include "connect.php"; ?>
<div class="container">
    <div class="row">
        <div class="col-lg-6 col-md-6 col-sm-6 col-sm-offset-3">
            <div class="panel panel-primary">
                <div class="panel panel-heading">
                    Update Courier Status
                </div>
                <div class="panel panel-body">
                    <form action="update1.php" method="post">
                        <?php $rowCount = count($_POST["name"]);
                        for($i=0;$i<$rowCount;$i++) {
                        $sql1 = mysql_query("SELECT * FROM courier_table WHERE cid='" . $_POST["name"][$i] . "'") or die(mysql_error());
                        $row[$i]= mysql_fetch_array($sql1);
                        ?>
                        <div class="panel panel-body">
                            <div class="col-lg-12 col-md-12 col-sm-12">
                                <label for="name">Order # :</label>
                                <input type="hidden" name="cid[]" class="txtField" value="<?php echo $row[$i][0]; ?>">
                                <input name="order_no[]" type="number" value="<?= $row[$i][5] ?>"   class="form-control" readonly>

                            </div>
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
<?php   $sql1 = mysql_query("SELECT * FROM courier_table ") or die(mysql_error());
$row1[$i]= mysql_fetch_array($sql1); { ?>
                                <label >Dispatch to:</label>
                                <select name="username[]" class="form-control" required>
                                    <option value="<?= $row1[$i] ?>"><?= $row[$i][7] ?></option>
                                </select>
                            <?php } ?></div>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <br>
                        <input type='submit' name='update' class="btn btn-primary btn-block" value='Update' />
                    </div>
                        <?php } ?>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
