<?php include "header.php"; ?>
<script type="text/javascript">
function validateForm()
{
var x=document.forms["reg"]["username"].value
var y=document.forms["reg"]["password"].value
var z=document.forms["reg"]["rpassword"].value
var t=document.forms["reg"]["question"].value
var b=document.forms["reg"]["answer"].value
var c=document.forms["reg"]["fname"].value
var d=document.forms["reg"]["lname"].value
var e=document.forms["reg"]["day"].value
var f=document.forms["reg"]["month"].value
var g=document.forms["reg"]["year"].value
var h=document.forms["reg"]["occupation"].value
var i=document.forms["reg"]["email"].value
var j=document.forms["reg"]["mobile"].value
var k=document.forms["reg"]["nationality"].value
var l=document.forms["reg"]["address"].value
var m=document.forms["reg"]["city"].value
var n=document.forms["reg"]["state"].value
var o=document.forms["reg"]["zip"].value
var p=document.forms["reg"]["country"].value
if (x==null || x=="")
  {
  alert("Username must be filled out");
  return false;
  }
if (y==null || y=="")
  {
  alert("Please enter your password");
  return false;
  }
if (z==null || z=="")
  {
  alert("Please re-enter your password");
  return false;
  }
if (t=="9")
  {
  alert("Please select a security question");
  return false;
  }
if (b==null || b=="")
  {
  alert("Please give your answer to the security question");
  return false;
  }
if (c==null || c=="")
  {
  alert("First name must be filled out");
  return false;
  }
if (d==null || d=="")
  {
  alert("Last name must be filled out");
  return false;
  }
if (e=="00")
  {
  alert("Please enter a date");
  return false;
  }
if (f=="0")
  {
  alert("Please enter month");
  return false;
  }
if (g=="")
  {
  alert("Please enter year");
  return false;
  }
if (h=="7")
  {
  alert("Please select your occupation");
  return false;
  }
var atpos=i.indexOf("@");
var dotpos=i.lastIndexOf(".");
if (atpos<1 || dotpos<atpos+2 || dotpos+2>=i.length)
  {
  alert("Not a valid e-mail address");
  return false;
  }
if (j==null || j=="")
  {
  alert("Please enter your mobile number");
  return false;
  }
if (k=="")
  {
  alert("Please select your nationality");
  return false;
  }
if (l==null || l=="")
  {
  alert("Address must be filled out");
  return false;
  }
if (m=="")
  {
  alert("Please select your city");
  return false;
  }
if (n=="")
  {
  alert("Please select your state");
  return false;
  }
if (o==null || o=="")
  {
  alert("Please enter pincode");
  return false;
  }
if (p=="")
  {
  alert("Please select your country");
  return false;
  }

}
</script>

<body>
<div class="container">
    <div class="row">
        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12"></div>
        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <div class="panel panel-primary">
                <div class="panel panel-heading">
                    Register Here
                </div>

                <form name="reg" action='admin/insert.php' onsubmit="return validateForm();" method='post'>
                    <div class="panel panel-body">
                        <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
                            <label for="usertpe">User Type</label>
                            <select name="type" class="form-control">
                                <option value = "client">Client</option>
                                <option value = "employee">Employee</option>
                            </select>
                        </div>
                        <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
                            <label for="name">Username</label>
                            <input type="text" name="username" size="20" maxlength="20" class="form-control
">
                        </div>
                        <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
                            <label>Password</label>
                            <input type="password" name="password" size="30" maxlength="30" class="form-control">
                        </div>
                        <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
                            <label>repeat Password</label>
                            <input type="password" name="rpassword" size="30" maxlength="30" class="form-control">
                        </div><div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
                            <label for="name">Name</label>
                            <input type="text" name="fname" size="15" maxlength="15" class="form-control">
                        </div>
                        <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
                            <label for="email">E-mail id</label>
                            <td><input type="text" name="email" size="50" maxlength="50" class="form-control">
                        </div>
                        <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
                            <label>Mobile</label>
                            <input type="text" name="mobile" size="10" maxlength="14" class="form-control">
                        </div>
                        <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
                            <label>Address</label>
                            <input type="text" name="address" size="30" maxlength="30" class="form-control">
                        </div>
                        <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
                            <label for="name">City&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>
                            <input type="text" name="city" size="15" maxlength="15" class="form-control">
                        </div>

                        <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
                            <br>
                            <input type="submit" name="submit" value="Submit" class="btn btn-primary">&nbsp;&nbsp;&nbsp;&nbsp;
                            <input type="reset" name="clear" value="Reset" class="btn btn-danger">
                            <hr><a href="index.php" class="btn btn-link btn-block">Go to login page </a>
                        </div>

                    </div>
                </form>
            </div>

        </div>
        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12"></div>
    </div>
</div>

</body>
</html>