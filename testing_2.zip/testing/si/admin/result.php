<?php include('header.php')?>
    <nav class="navbar navbar-default">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">Courier Management System</a>
            </div>
            <div class="collapse navbar-collapse" id="myNavbar">
                <ul class="nav navbar-nav">
                    <li class="active"><a href="admin/admin.php">Home</a></li>
                    <li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
                </ul>

            </div>
        </div>
    </nav>

    <div id="" class="">
    <div class="row">
    <div class="col-lg-2 col-md-2 col-sm-2">
        <?php include "left.php"; ?>
    </div>
    <div class="col-lg-10 col-md-10 col-sm-10">
<?php

$con=mysql_connect("localhost","root","");
if(!$con)
{
    die('could not connect'.mysql_error());
}
mysql_select_db("courier",$con);
if($_POST['search']) {
    $key = $_POST['search'];
    $sql = "select * from courier_table WHERE name=$key OR cno=$key OR order_no=$key";

//$sql1="select * from courier_table  /* where `status`='Paid'*/";
// $sql2="select * from courier_table where `status`='Pending'";
// $sql3="select * from courier_table where `status`='Delivered'";
    $sql4 = "select * from courier_table";
    $result1 = mysql_query($sql, $con);
// $result2=mysql_query($sql2,$con);
// $result3=mysql_query($sql3,$con);
    $result4 = mysql_query($sql4, $con);
    include("report1.php");
    if (!$result1) {
        echo "Error!" . "</br>";
        include 'report.php';
    } else {
        echo "<table>";

        echo "<thead><th><input type='checkbox' name='check_list[<?php echo $row[0] ?>]' value='<?= $row[0]?>' /></th><th>Name </th><th>Contact_No </th><th>Email </th><th>Amount</th><th> Order # </th><th>Date </th>
<th>Assign to </th><th> Address </th><th>Status</th></thead>";
        while ($row = mysql_fetch_row($result1)) {

            echo "<tr><td><input type='checkbox' name='name1' '.($row[0] == 1 ? 'checked' : '').' value='1'/></td><td>$row[1]</td><td>$row[2]</td><td>$row[3]</td><td>$row[4]</td>
<td>$row[5]</td><td>$row[6]</td><td>$row[7]</td><td>$row[8]</td><td>$row[9]</td></tr>";


        }
        echo "</table>";
        echo "</br>";
    }

}
?>